﻿<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

require_once __DIR__ . '/../../config/empresa.php';
require_once CONEXION_BD_PATH;
require_once FPDF_PATH;

$input = json_decode(file_get_contents('php://input'), true);
$fechaInicio = $input['fechaInicio'] ?? '';
$fechaFin = $input['fechaFin'] ?? '';
$clienteNombre = $input['clienteNombre'] ?? 'Todos los clientes';
$pedidos = $input['pedidos'] ?? [];
$totales = $input['totales'] ?? [];

class PDF_CC extends FPDF {
    function Header() {
        $this->SetFont('Arial', 'B', 9);
        $this->Cell(0, 6, constant('EMPRESA_NOMBRE_TITULO'), 0, 1, 'C');
        $this->SetFont('Arial', 'I', 7);
        $this->Cell(0, 4, constant('EMPRESA_NIT'), 0, 1, 'C');
        $this->Ln(2);
        $this->SetDrawColor(100, 50, 200);
        $this->Line(10, $this->GetY(), 200, $this->GetY());
        $this->Ln(4);
    }
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 7);
        $this->Cell(0, 10, 'Pag ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }
}

$pdf = new PDF_CC();
$pdf->AliasNbPages();
$pdf->AddPage();

$pdf->SetFont('Arial', 'B', 14);
$pdf->SetTextColor(100, 50, 200);
$pdf->Cell(0, 10, 'CUENTA DE COBRO - COMISIONES', 0, 1, 'C');
$pdf->SetTextColor(0, 0, 0);

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 7, 'Periodo: ' . $fechaInicio . ' al ' . $fechaFin, 0, 1, 'C');
$pdf->Cell(0, 7, 'Cliente: ' . $clienteNombre, 0, 1, 'C');
$pdf->Ln(5);

// Tabla
$pdf->SetFont('Arial', 'B', 7);
$pdf->SetFillColor(220, 210, 255);
$pdf->Cell(50, 6, 'N Pedido', 1, 0, 'C', true);
$pdf->Cell(40, 6, 'Fecha', 1, 0, 'C', true);
$pdf->Cell(40, 6, 'Valor Total', 1, 0, 'C', true);
$pdf->Cell(25, 6, '% Comision', 1, 0, 'C', true);
$pdf->Cell(35, 6, 'Comision a Cobrar', 1, 1, 'C', true);

$pdf->SetFont('Arial', '', 7);
$totalValor = 0;
$totalComision = 0;

foreach ($pedidos as $p) {
    $val = floatval($p['valorTotal'] ?? 0);
    $com = floatval($p['comision'] ?? 0);
    $pct = floatval($p['PorcentajeComision'] ?? 0);
    $totalValor += $val;
    $totalComision += $com;

    $pdf->Cell(50, 5, $p['numeroPedido'] ?? ('ID: ' . $p['idPedido']), 1);
    $pdf->Cell(40, 5, $p['fecha'] ?? '-', 1, 0, 'C');
    $pdf->Cell(40, 5, '$' . number_format($val, 2), 1, 0, 'R');
    $pdf->Cell(25, 5, number_format($pct, 2) . '%', 1, 0, 'C');
    $pdf->Cell(35, 5, '$' . number_format($com, 2), 1, 1, 'R');
}

$pdf->SetFont('Arial', 'B', 8);
$pdf->SetFillColor(240, 235, 255);
$pdf->Cell(90, 6, 'TOTALES:', 1, 0, 'R', true);
$pdf->Cell(40, 6, '$' . number_format($totalValor, 2), 1, 0, 'R', true);
$pdf->Cell(25, 6, '', 1, 0, 'C', true);
$pdf->Cell(35, 6, '$' . number_format($totalComision, 2), 1, 1, 'R', true);

$pdf->Ln(10);

// Resumen
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetFillColor(200, 255, 200);
$pdf->Cell(0, 8, 'RESUMEN DE COBRO', 1, 1, 'C', true);
$pdf->SetFont('Arial', 'B', 9);
$pdf->Cell(130, 7, 'Cantidad de Pedidos:', 1, 0);
$pdf->Cell(60, 7, count($pedidos), 1, 1, 'R');
$pdf->Cell(130, 7, 'Valor Total de Productos:', 1, 0);
$pdf->Cell(60, 7, '$' . number_format($totalValor, 2), 1, 1, 'R');
$pdf->SetFillColor(220, 255, 220);
$pdf->Cell(130, 7, 'TOTAL COMISION A COBRAR:', 1, 0, '', true);
$pdf->Cell(60, 7, '$' . number_format($totalComision, 2), 1, 1, 'R', true);

header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="CuentaCobro_' . $fechaInicio . '_' . $fechaFin . '.pdf"');
$pdf->Output('I');

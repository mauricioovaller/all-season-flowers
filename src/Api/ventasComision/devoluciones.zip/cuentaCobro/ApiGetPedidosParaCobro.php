﻿<?php
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { echo json_encode(['success'=>false]); exit; }

require_once __DIR__ . '/../../config/empresa.php';
require_once CONEXION_BD_PATH;

$input = json_decode(file_get_contents('php://input'), true) ?? [];
$fechaInicio = $input['fechaInicio'] ?? '';
$fechaFin = $input['fechaFin'] ?? '';
$idCliente = intval($input['idCliente'] ?? 0);

if (!$fechaInicio || !$fechaFin) {
    echo json_encode(['success'=>false, 'pedidos'=>[], 'totalPedidos'=>0, 'message'=>'Rango de fechas requerido']);
    exit;
}

try {
    $where = ["p.Estado = 'Activo'"];
    $where[] = "p.FechaSolicitud >= '" . $enlace->real_escape_string($fechaInicio) . "'";
    $where[] = "p.FechaSolicitud <= '" . $enlace->real_escape_string($fechaFin) . "'";

    if ($idCliente > 0) {
        $where[] = "p.IdCliente = $idCliente";
    }

    $whereClause = "WHERE " . implode(" AND ", $where);

    $sql = "SELECT p.IdEncabPedidoComision AS idPedido, p.NumeroPedido,
        p.FechaSolicitud AS fecha, p.PorcentajeComision,
        c.NOMBRE AS cliente,
        (SELECT COALESCE(SUM(
            GREATEST(dp.Tallos_Ramo * dp.Ramos_Caja * de.Cantidad - COALESCE(dp.TallosDevolucion, 0), 0) * dp.Precio_Venta
         ), 0)
         FROM SAS_DetProductoComision dp
         INNER JOIN SAS_DetEmpaqueComision de ON dp.IdDetEmpaqueComision = de.IdDetEmpaqueComision
         WHERE dp.IdEncabPedidoComision = p.IdEncabPedidoComision
         AND (dp.Anulado IS NULL OR dp.Anulado = 0)
         AND (de.Anulado IS NULL OR de.Anulado = 0)
        ) AS valorTotal
        FROM SAS_EncabPedidoComision p
        LEFT JOIN GEN_Clientes c ON p.IdCliente = c.IdCliente
        $whereClause
        ORDER BY p.FechaSolicitud, p.NumeroPedido";

    $result = $enlace->query($sql);
    if (!$result) throw new Exception("Error en SELECT: " . $enlace->error);

    $pedidos = [];
    while ($row = $result->fetch_assoc()) {
        $pctGlobal = floatval($row['PorcentajeComision'] ?? 0);

        // Calcular comisiÃ³n real por pedido (descontando tallos devueltos)
        $sql2 = "SELECT COALESCE(SUM(
            GREATEST(dp.Tallos_Ramo * dp.Ramos_Caja * de.Cantidad - COALESCE(dp.TallosDevolucion, 0), 0) * dp.Precio_Venta *
            (COALESCE(dp.PorcentajeComision, $pctGlobal, 0) / 100)
        ), 0) AS totalComision
        FROM SAS_DetProductoComision dp
        INNER JOIN SAS_DetEmpaqueComision de ON dp.IdDetEmpaqueComision = de.IdDetEmpaqueComision
        WHERE dp.IdEncabPedidoComision = " . intval($row['idPedido']) . "
        AND (dp.Anulado IS NULL OR dp.Anulado = 0)
        AND (de.Anulado IS NULL OR de.Anulado = 0)";

        $r2 = $enlace->query($sql2);
        if ($r2) {
            $row['comision'] = floatval($r2->fetch_assoc()['totalComision'] ?? 0);
        } else {
            $row['comision'] = 0;
        }

        $pedidos[] = $row;
    }

    echo json_encode(['success'=>true, 'pedidos'=>$pedidos, 'totalPedidos'=>count($pedidos)]);
} catch (Exception $e) {
    echo json_encode(['success'=>false, 'pedidos'=>[], 'totalPedidos'=>0, 'message'=>$e->getMessage()]);
}

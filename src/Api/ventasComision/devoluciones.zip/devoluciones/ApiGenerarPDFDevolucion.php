﻿<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

require_once __DIR__ . '/../../config/empresa.php';
require_once CONEXION_BD_PATH;
require_once FPDF_PATH;

$input = json_decode(file_get_contents('php://input'), true);
$idFactura = intval($input['idFactura'] ?? 0);
if ($idFactura <= 0) { http_response_code(400); exit; }

// Obtener datos
$result = $enlace->query("SELECT e.*, c.NOMBRE AS NOMBRECLIENTE, c.PAIS, m.Moneda AS NOMBREMONEDA
    FROM SAS_EncabPedidoComision e
    LEFT JOIN GEN_Clientes c ON e.IdCliente = c.IdCliente
    LEFT JOIN GEN_Monedas m ON e.IdMoneda = m.IdMoneda
    WHERE e.IdEncabPedidoComision = $idFactura");
$encab = $result->fetch_assoc();

if (!$encab) { http_response_code(404); exit; }

// Detalle con devoluciones
$result = $enlace->query("SELECT dp.*, pr.NOMPRODUCTO AS nomProducto,
    v.NOMVARIEDAD AS NOMBREVARIEDAD, g.NOMGRADO AS NOMBREGRADO,
    (dp.Tallos_Ramo * dp.Ramos_Caja * de.Cantidad) AS tallosFacturados
    FROM SAS_DetProductoComision dp
    INNER JOIN SAS_DetEmpaqueComision de ON dp.IdDetEmpaqueComision = de.IdDetEmpaqueComision
    LEFT JOIN GEN_Productos pr ON dp.IdProducto = pr.IdProducto
    LEFT JOIN GEN_Variedades v ON dp.IdVariedad = v.IdVariedad
    LEFT JOIN GEN_Grados g ON dp.IdGrado = g.IdGrado
    WHERE dp.IdEncabPedidoComision = $idFactura AND (dp.Anulado IS NULL OR dp.Anulado = 0)
    AND dp.TallosDevolucion IS NOT NULL AND dp.TallosDevolucion > 0");
$detalle = $result->fetch_all(MYSQLI_ASSOC);

$numDev = 'DEV-' . str_pad(intval($encab['IdDevolucion'] ?? 0), 6, '0', STR_PAD_LEFT);

// PDF
class PDF_DC extends FPDF {
    function Header() {
        $this->SetFont('Arial', 'B', 9);
        $this->Cell(0, 6, constant('EMPRESA_NOMBRE_TITULO'), 0, 1, 'C');
        $this->SetFont('Arial', 'I', 7);
        $this->Cell(0, 4, constant('EMPRESA_NIT'), 0, 1, 'C');
        $this->Ln(2);
        $this->SetDrawColor(100, 50, 200);
        $this->Line(10, $this->GetY(), 200, $this->GetY());
        $this->Ln(4);
    }
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 7);
        $this->Cell(0, 10, 'Pag ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }
}

$pdf = new PDF_DC();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 14);
$pdf->SetTextColor(100, 50, 200);
$pdf->Cell(0, 10, 'DEVOLUCION - VENTAS COMISION', 0, 1, 'C');
$pdf->SetTextColor(0, 0, 0);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 7, 'N: ' . $numDev, 0, 1, 'R');
$pdf->Ln(2);

// Datos
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetFillColor(240, 235, 255);
$pdf->Cell(0, 6, 'DATOS DE LA DEVOLUCION', 0, 1, '', true);
$pdf->SetFont('Arial', '', 8);
$pdf->Cell(95, 5, 'Cliente: ' . ($encab['NOMBRECLIENTE'] ?? '-'), 0, 0);
$pdf->Cell(95, 5, 'Fecha Devolucion: ' . ($encab['FechaDevolucion'] ?? '-'), 0, 1);
$pdf->Cell(95, 5, 'Pedido: ' . ($encab['NumeroPedido'] ?? '-'), 0, 0);
$pdf->Cell(95, 5, 'Moneda: ' . ($encab['NOMBREMONEDA'] ?? '-'), 0, 1);
$pdf->Ln(5);

if (!empty($encab['ObservacionesDevolucion'])) {
    $pdf->SetFont('Arial', 'I', 8);
    $pdf->MultiCell(0, 4, 'Observaciones: ' . $encab['ObservacionesDevolucion'], 0, 1);
    $pdf->Ln(3);
}

// Tabla
$pdf->SetFont('Arial', 'B', 7);
$pdf->SetFillColor(220, 210, 255);
$pdf->Cell(50, 6, 'Producto', 1, 0, 'C', true);
$pdf->Cell(22, 6, 'Variedad', 1, 0, 'C', true);
$pdf->Cell(16, 6, 'Grado', 1, 0, 'C', true);
$pdf->Cell(18, 6, 'Tallos Fact.', 1, 0, 'C', true);
$pdf->Cell(18, 6, 'Tallos Dev.', 1, 0, 'C', true);
$pdf->Cell(18, 6, 'Precio', 1, 0, 'C', true);
$pdf->Cell(20, 6, 'Valor', 1, 0, 'C', true);
$pdf->Cell(22, 6, 'Motivo', 1, 1, 'C', true);

$pdf->SetFont('Arial', '', 7);
$totalValor = 0;
foreach ($detalle as $d) {
    $tallosDev = intval($d['TallosDevolucion'] ?? 0);
    $precio = floatval($d['Precio_Venta'] ?? 0);
    $valor = $tallosDev * $precio + floatval($d['Flete'] ?? 0) + floatval($d['Fumigacion'] ?? 0) + floatval($d['Otros'] ?? 0);
    $totalValor += $valor;

    $pdf->Cell(50, 5, substr($d['nomProducto'] ?? $d['Descripcion'] ?? '-', 0, 28), 1);
    $pdf->Cell(22, 5, substr($d['NOMBREVARIEDAD'] ?? '-', 0, 12), 1);
    $pdf->Cell(16, 5, substr($d['NOMBREGRADO'] ?? '-', 0, 8), 1);
    $pdf->Cell(18, 5, intval($d['tallosFacturados'] ?? 0), 1, 0, 'C');
    $pdf->Cell(18, 5, $tallosDev, 1, 0, 'C');
    $pdf->Cell(18, 5, number_format($precio, 2), 1, 0, 'R');
    $pdf->Cell(20, 5, '$' . number_format($valor, 2), 1, 0, 'R');
    $pdf->Cell(22, 5, substr($d['MotivoDevolucion'] ?? '', 0, 12), 1, 1);
}

$pdf->SetFont('Arial', 'B', 8);
$pdf->SetFillColor(240, 235, 255);
$pdf->Cell(162, 6, 'TOTAL DEVOLUCION:', 1, 0, 'R', true);
$pdf->Cell(22, 6, '$' . number_format($totalValor, 2), 1, 1, 'R', true);

header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="Devolucion_' . $numDev . '.pdf"');
$pdf->Output('I');

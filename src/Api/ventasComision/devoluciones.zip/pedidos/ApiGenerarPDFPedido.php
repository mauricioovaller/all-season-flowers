﻿<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

require_once __DIR__ . '/../../config/empresa.php';
require_once CONEXION_BD_PATH;
require_once FPDF_PATH;

$input = json_decode(file_get_contents('php://input'), true);
$idPedido = intval($input['idPedido'] ?? 0);
if ($idPedido <= 0) { http_response_code(400); echo json_encode(['error'=>'ID invÃ¡lido']); exit; }

// Obtener datos del pedido
$result = $enlace->query("SELECT e.*, c.NOMBRE AS NOMBRECLIENTE, c.PAIS,
    CONCAT(c.Direc1, ', ', c.CIUDAD, ', ', c.ESTADO, ', ', c.PAIS) AS DIRECCIONCLIENTE,
    m.Moneda AS NOMBREMONEDA, ev.NOMEJECUTIVO AS NOMBREJECUTIVOVENTA
    FROM SAS_EncabPedidoComision e
    LEFT JOIN GEN_Clientes c ON e.IdCliente = c.IdCliente
    LEFT JOIN GEN_Monedas m ON e.IdMoneda = m.IdMoneda
    LEFT JOIN GEN_Ejecutivos ev ON e.IdEjecutivo = ev.IdEjecutivo
    WHERE e.IdEncabPedidoComision = $idPedido");
$encab = $result->fetch_assoc();
if (!$encab) { http_response_code(404); echo json_encode(['error'=>'No encontrado']); exit; }

// Obtener empaques y productos
$empaques = [];
$resEmp = $enlace->query("SELECT de.*, te.Descripcion AS NOMBREEMPAQUE FROM SAS_DetEmpaqueComision de
    LEFT JOIN GEN_TipoEmpaque te ON de.IdTipoEmpaque = te.IdTipoEmpaque
    WHERE de.IdEncabPedidoComision = $idPedido AND (de.Anulado IS NULL OR de.Anulado = 0)");
while ($row = $resEmp->fetch_assoc()) {
    $idDet = intval($row['IdDetEmpaqueComision']);
    $resProd = $enlace->query("SELECT dp.*, pr.NOMPRODUCTO AS nomProducto,
        v.NOMVARIEDAD, g.NOMGRADO, u.DescripUnidad AS NOMBREUNIDAD
        FROM SAS_DetProductoComision dp
        LEFT JOIN GEN_Productos pr ON dp.IdProducto = pr.IdProducto
        LEFT JOIN GEN_Variedades v ON dp.IdVariedad = v.IdVariedad
        LEFT JOIN GEN_Grados g ON dp.IdGrado = g.IdGrado
        LEFT JOIN GEN_Unidades u ON dp.IdUnidad = u.IdUnidades
        WHERE dp.IdDetEmpaqueComision = $idDet AND (dp.Anulado IS NULL OR dp.Anulado = 0)");
    $row['productos'] = $resProd->fetch_all(MYSQLI_ASSOC);
    $empaques[] = $row;
}

// LOGO
$logoPath = constant('EMPRESA_LOGO_PATH');

class PDF_PC extends FPDF {
    function Header() {
        $this->SetFont('Arial', 'B', 9);
        $this->Cell(0, 6, constant('EMPRESA_NOMBRE_TITULO'), 0, 1, 'C');
        $this->SetFont('Arial', 'I', 7);
        $this->Cell(0, 4, constant('EMPRESA_NIT'), 0, 1, 'C');
        $this->Ln(2);
        $this->SetDrawColor(100, 50, 200);
        $this->Line(10, $this->GetY(), 200, $this->GetY());
        $this->Ln(4);
    }
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 7);
        $this->Cell(0, 10, 'Pag ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }
}

$pdf = new PDF_PC();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetAutoPageBreak(true, 20);

// Logo
if (file_exists($logoPath)) {
    $pdf->Image($logoPath, 10, 10, 30, 0, 'JPG');
    $pdf->SetY(25);
}

$pdf->SetY($pdf->GetY() + 5);

// TÃ­tulo
$pdf->SetFont('Arial', 'B', 14);
$pdf->SetTextColor(100, 50, 200);
$pdf->Cell(0, 10, 'PEDIDO - VENTAS COMISION', 0, 1, 'C');
$pdf->SetTextColor(0, 0, 0);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 7, 'N: ' . $encab['NumeroPedido'], 0, 1, 'R');
$pdf->Ln(2);

// Datos del pedido
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetFillColor(240, 235, 255);
$pdf->Cell(0, 6, 'DATOS DEL PEDIDO', 0, 1, '', true);
$pdf->SetFont('Arial', '', 8);
$pdf->Cell(95, 5, 'Cliente: ' . ($encab['NOMBRECLIENTE'] ?? '-'), 0, 0);
$pdf->Cell(95, 5, 'Fecha Solicitud: ' . ($encab['FechaSolicitud'] ?? '-'), 0, 1);
$pdf->Cell(95, 5, 'Pais: ' . ($encab['PAIS'] ?? '-'), 0, 0);
$pdf->Cell(95, 5, 'Fecha Entrega: ' . ($encab['FechaEntrega'] ?? '-'), 0, 1);
$pdf->Cell(95, 5, 'Ejecutivo: ' . ($encab['NOMBREJECUTIVOVENTA'] ?? '-'), 0, 0);
$pdf->Cell(95, 5, 'Estado: ' . ($encab['Estado'] ?? 'Activo'), 0, 1);
$pdf->Cell(95, 5, 'Moneda: ' . ($encab['NOMBREMONEDA'] ?? '-') . ' - TRM: ' . number_format(floatval($encab['TRM'] ?? 0), 2), 0, 0);
$pdf->Cell(95, 5, '% Comision Global: ' . number_format(floatval($encab['PorcentajeComision'] ?? 0), 2) . '%', 0, 1);
$pdf->Ln(3);

// Detalle
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetFillColor(240, 235, 255);
$pdf->Cell(0, 6, 'DETALLE DEL PEDIDO', 0, 1, '', true);

$totalGeneral = 0;
$totalComision = 0;
$pctGlobal = floatval($encab['PorcentajeComision'] ?? 0);

foreach ($empaques as $emp) {
    $pdf->SetFont('Arial', 'B', 8);
    $pdf->SetFillColor(245, 245, 245);
    $pdf->Cell(0, 5, 'Empaque: ' . ($emp['NOMBREEMPAQUE'] ?? 'N/D') . ' x ' . intval($emp['Cantidad']) . ' unid' . ($emp['PO_Empaque'] ? ' - PO: ' . $emp['PO_Empaque'] : ''), 0, 1, '', true);

    // Cabecera
    $pdf->SetFont('Arial', 'B', 6.5);
    $pdf->SetFillColor(220, 210, 255);
    $pdf->Cell(48, 5, 'Producto', 1, 0, 'C', true);
    $pdf->Cell(22, 5, 'Variedad', 1, 0, 'C', true);
    $pdf->Cell(16, 5, 'Grado', 1, 0, 'C', true);
    $pdf->Cell(10, 5, 'T/R', 1, 0, 'C', true);
    $pdf->Cell(10, 5, 'R/C', 1, 0, 'C', true);
    $pdf->Cell(18, 5, 'Precio', 1, 0, 'C', true);
    $pdf->Cell(13, 5, '%Com', 1, 0, 'C', true);
    $pdf->Cell(24, 5, 'Valor Producto', 1, 0, 'C', true);
    $pdf->Cell(22, 5, 'Comision', 1, 1, 'C', true);

    $pdf->SetFont('Arial', '', 6.5);
    $subtotalEmp = 0;
    $comisionEmp = 0;

    foreach ($emp['productos'] as $prod) {
        $tallosRamo = intval($prod['Tallos_Ramo'] ?? 0);
        $ramosCaja = intval($prod['Ramos_Caja'] ?? 0);
        $tallosCaja = $tallosRamo * $ramosCaja;
        $precio = floatval($prod['Precio_Venta'] ?? 0);
        $subtotal = $tallosCaja * $precio;
        $pctItem = $prod['PorcentajeComision'] !== null ? floatval($prod['PorcentajeComision']) : $pctGlobal;
        $comision = $subtotal * ($pctItem / 100);
        $subtotalEmp += $subtotal;
        $comisionEmp += $comision;

        $pdf->Cell(48, 4, substr($prod['nomProducto'] ?? $prod['Descripcion'] ?? '-', 0, 28), 1);
        $pdf->Cell(22, 4, substr($prod['NOMVARIEDAD'] ?? '-', 0, 14), 1);
        $pdf->Cell(16, 4, substr($prod['NOMGRADO'] ?? '-', 0, 10), 1);
        $pdf->Cell(10, 4, $tallosRamo, 1, 0, 'C');
        $pdf->Cell(10, 4, $ramosCaja, 1, 0, 'C');
        $pdf->Cell(18, 4, number_format($precio, 2), 1, 0, 'R');
        $pdf->Cell(13, 4, number_format($pctItem, 1) . '%', 1, 0, 'C');
        $pdf->Cell(24, 4, '$' . number_format($subtotal, 2), 1, 0, 'R');
        $pdf->Cell(22, 4, '$' . number_format($comision, 2), 1, 1, 'R');
    }

    $pdf->SetFont('Arial', 'B', 7);
    $pdf->SetFillColor(240, 235, 255);
    $pdf->Cell(137, 5, 'Subtotal Empaque:', 1, 0, 'R', true);
    $pdf->Cell(24, 5, '$' . number_format($subtotalEmp, 2), 1, 0, 'R', true);
    $pdf->Cell(22, 5, '$' . number_format($comisionEmp, 2), 1, 1, 'R', true);

    $totalGeneral += $subtotalEmp;
    $totalComision += $comisionEmp;
    $pdf->Ln(2);
}

// Totales
$pdf->Ln(3);
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetFillColor(100, 50, 200);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell(137, 7, 'TOTAL GENERAL PRODUCTOS', 1, 0, 'C', true);
$pdf->Cell(46, 7, '$' . number_format($totalGeneral, 2), 1, 1, 'R', true);

$pdf->SetTextColor(0, 0, 0);
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetFillColor(200, 255, 200);
$pdf->Cell(137, 7, 'TOTAL COMISION A COBRAR', 1, 0, 'C', true);
$pdf->Cell(46, 7, '$' . number_format($totalComision, 2), 1, 1, 'R', true);

if ($encab['IVA']) {
    $iva = $totalGeneral * 0.19;
    $pdf->SetFont('Arial', 'B', 9);
    $pdf->SetFillColor(255, 255, 220);
    $pdf->Cell(137, 6, 'IVA 19%', 1, 0, 'R', true);
    $pdf->Cell(46, 6, '$' . number_format($iva, 2), 1, 1, 'R', true);
}

if (!empty($encab['Observaciones'])) {
    $pdf->Ln(3);
    $pdf->SetFont('Arial', 'B', 8);
    $pdf->Cell(0, 5, 'Observaciones:', 0, 1);
    $pdf->SetFont('Arial', '', 7);
    $pdf->MultiCell(0, 4, $encab['Observaciones'], 0, 1);
}

// Output PDF directly
header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="Pedido_' . $encab['NumeroPedido'] . '.pdf"');
$pdf->Output('I');
